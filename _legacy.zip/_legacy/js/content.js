// content.js
// Behaviours attached to the page content:
//   - progress  : persisted checkboxes, per-level bars, curriculum overview
//   - resources : collapsible dashboard widgets + <details class="res"> lists
//   - library   : the Reference Library search/category filter
//   - toc       : the per-tab "On this page" rail + mobile drawer + scrollspy
// All of it is exported through a single initContent() that app.js calls once.

import { LS, slugify, escHtml, routeUrl } from './util.js';

/* ============================ progress ============================ */

const LEVELS = ['tech1', 'tech2', 'prestaff', 'lvl0', 'lvl1', 'lvl2', 'lvl3', 'lvl4', 'lvl5', 'lvl6', 'lvl7', 'leadsheets'];
const OVERVIEW_LEVELS = [
  ['tech1', 'Technique 1 \u00b7 Body', 'technique-1'], ['tech2', 'Technique 2 \u00b7 Hands', 'technique-2'],
  ['prestaff', 'Pre-Staff', 'pre-staff'], ['lvl0', 'Level 0 \u00b7 Linear', 'level-0'],
  ['lvl1', 'Level 1 \u00b7 Intervals', 'level-1'], ['lvl2', 'Level 2 \u00b7 Voices', 'level-2'],
  ['lvl3', 'Level 3 \u00b7 Shifting', 'level-3'], ['lvl4', 'Level 4 \u00b7 Inversions', 'level-4'],
  ['lvl5', 'Level 5 \u00b7 Polyphony', 'level-5'], ['lvl6', 'Level 6 \u00b7 Counterpoint', 'level-6'],
  ['lvl7', 'Level 7 \u00b7 Polytonal', 'level-7'], ['leadsheets', 'Harmony \u00b7 Lead Sheets', 'lead-sheets-l1']
];

function toggleCompletedState(cb) {
  const row = cb.closest('.widget-row');
  if (row) row.classList.toggle('completed', cb.checked);
}

// Global checklist progress alignment
function updateLevelProgress(level) {
  const total = document.querySelectorAll(`input[data-level="${level}"]`).length;
  const checked = document.querySelectorAll(`input[data-level="${level}"]:checked`).length;
  const bar = document.getElementById(`progress-${level}`);
  const pctText = document.getElementById(`percent-${level}`);
  if (bar) {
    const pct = total > 0 ? Math.round((checked / total) * 100) : 0;
    bar.style.width = pct + '%';
    if (pctText) pctText.textContent = pct + '%';
  }
}

function levelPct(level) {
  const boxes = document.querySelectorAll(`.widget-checkbox[data-level="${level}"]`);
  if (!boxes.length) return 0;
  return Math.round([...boxes].filter(b => b.checked).length / boxes.length * 100);
}

function renderOverview() {
  const wrap = document.getElementById('curriculumOverview');
  if (!wrap) return;
  let total = 0, count = 0, rows = '';
  OVERVIEW_LEVELS.forEach(([dl, name, sec]) => {
    const pct = levelPct(dl); total += pct; count++;
    rows += '<div class="po-row" onclick="switchSection(\'' + sec + '\')">'
      + '<div class="po-top"><span class="po-name">' + name + '</span><span class="po-pct">' + pct + '%</span></div>'
      + '<div class="po-bar-bg"><div class="po-bar-fg" style="width:' + pct + '%"></div></div></div>';
  });
  const overall = count ? Math.round(total / count) : 0;
  wrap.innerHTML = '<div class="po-overall"><div class="po-big">' + overall + '%</div>'
    + '<div class="po-cap">overall curriculum complete<br>across all ' + count + ' tracks. Tap any track to jump in</div></div>' + rows;
}

function initProgress() {
  document.querySelectorAll('input[type="checkbox"]').forEach(cb => {
    const saved = LS.get(cb.id);
    if (saved !== null) { cb.checked = saved === 'true'; toggleCompletedState(cb); }
    cb.addEventListener('change', () => {
      LS.set(cb.id, cb.checked);
      toggleCompletedState(cb);
      updateLevelProgress(cb.dataset.level);
    });
  });
  LEVELS.forEach(updateLevelProgress);
  document.addEventListener('change', (e) => {
    if (e.target.classList && e.target.classList.contains('widget-checkbox')) renderOverview();
  });
  renderOverview();
}

/* ============================ resources =========================== */

const CHECK_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4 4 10-10"/></svg>';

// Exposed to inline onclick="toggleCollapse(this)".
function toggleCollapse(header) {
  const widget = header.parentElement;
  widget.classList.toggle('collapsed');
  if (widget.dataset.cid) LS.set('cp-collapse-' + widget.dataset.cid, widget.classList.contains('collapsed'));
}

function initCollapsibles() {
  document.querySelectorAll('.dashboard-widget').forEach((w, i) => {
    const sec = w.closest('.content-section');
    const cid = (sec ? sec.id : 'x') + '-dw-' + i;
    w.dataset.cid = cid;
    const saved = LS.get('cp-collapse-' + cid);
    if (saved === 'true') w.classList.add('collapsed');
    else if (saved === 'false') w.classList.remove('collapsed');
  });
}

function updateMarkBtn(det) {
  const b = det._markBtn; if (!b) return;
  b.textContent = det.classList.contains('res-done') ? 'Done \u2713' : 'Mark as done';
}
function updateResProgress(list) {
  const head = list._progHead; if (!head) return;
  const items = list.querySelectorAll(':scope > details.res');
  const done = list.querySelectorAll(':scope > details.res.res-done').length;
  const pct = items.length ? Math.round(done / items.length * 100) : 0;
  head.querySelector('.rp-fill').style.width = pct + '%';
  head.querySelector('.rp-count').textContent = done + '/' + items.length;
}
function setResDone(det, done, skipSave) {
  det.classList.toggle('res-done', done);
  updateMarkBtn(det);
  if (!skipSave) LS.set('cp-done-' + det.dataset.rid, done);
  const list = det.closest('.res-list'); if (list) updateResProgress(list);
}

function initResourceLists() {
  document.querySelectorAll('.content-section .res-list').forEach((list) => {
    const sec = list.closest('.content-section');
    const secId = sec ? sec.id : 'x';
    const items = Array.from(list.querySelectorAll(':scope > details.res'));
    if (!items.length) return;

    items.forEach((det, idx) => {
      const rid = 'res::' + secId + '::' + idx;
      det.dataset.rid = rid;

      const openSaved = LS.get('cp-open-' + rid);
      if (openSaved === 'true') det.open = true;
      else if (openSaved === 'false') det.open = false;
      det.addEventListener('toggle', () => LS.set('cp-open-' + rid, det.open));

      const summary = det.querySelector(':scope > summary');
      if (summary) {
        let controls = summary.querySelector('.res-controls');
        if (!controls) {
            controls = document.createElement('div');
            controls.className = 'res-controls';
            summary.appendChild(controls);
        }

        if (!controls.querySelector('.res-done-toggle')) {
            const tog = document.createElement('button');
            tog.type = 'button'; tog.className = 'res-done-toggle';
            tog.setAttribute('aria-label', 'Mark resource as done');
            tog.innerHTML = CHECK_SVG;
            tog.style.marginLeft = '0'; // Clear custom CSS margin-left
            tog.addEventListener('click', (e) => { 
                e.preventDefault(); 
                e.stopPropagation(); 
                setResDone(det, !det.classList.contains('res-done')); 
            });
            controls.appendChild(tog);
        }
      }

      const more = det.querySelector(':scope > .res-more');
      if (more && !more.dataset.enhanced) {
        more.dataset.enhanced = '1';
        const dose = more.querySelector('.res-dose');
        if (dose) {
          const clone = dose.cloneNode(true);
          const lbl = clone.querySelector('.rd-label'); if (lbl) lbl.remove();
          const raw = clone.textContent.replace(/\s+/g, ' ').trim();
          let plan = raw, doneWhen = '';
          const m = raw.match(/^(.*?)(?:done when|done once)\s+(.*)$/i);
          if (m) {
            plan = m[1].replace(/[.\s]+$/, '').trim();
            doneWhen = m[2].trim();
            doneWhen = doneWhen.charAt(0).toUpperCase() + doneWhen.slice(1);
          }
          const grid = document.createElement('div');
          grid.className = 'res-meta-grid';
          grid.innerHTML =
            '<div class="res-cell"><span class="rc-label">Practice plan</span><span class="rc-text">' + escHtml(plan) + '</span></div>' +
            (doneWhen ? '<div class="res-cell"><span class="rc-label">Done when</span><span class="rc-text">' + escHtml(doneWhen) + '</span></div>' : '');
          dose.replaceWith(grid);
        }
        const openLink = more.querySelector('.res-open');
        const foot = document.createElement('div');
        foot.className = 'res-foot';
        const markBtn = document.createElement('button');
        markBtn.type = 'button'; markBtn.className = 'res-mark-btn';
        markBtn.addEventListener('click', () => setResDone(det, !det.classList.contains('res-done')));
        if (openLink) { openLink.parentNode.insertBefore(foot, openLink); foot.appendChild(openLink); }
        else more.appendChild(foot);
        foot.appendChild(markBtn);
        det._markBtn = markBtn;
      }

      if (LS.get('cp-done-' + rid) === 'true') setResDone(det, true, true);
      else updateMarkBtn(det);
    });

    const head = document.createElement('div');
    head.className = 'res-list-head';
    head.innerHTML = '<span class="res-progress"><span class="rp-track"><span class="rp-fill"></span></span><span class="rp-count">0/' + items.length + '</span> done</span>';
    list.parentNode.insertBefore(head, list);
    list._progHead = head;
    updateResProgress(list);
  });
}

/* ============================ library ============================= */

function filterLibrary() {
  const search = document.getElementById('libSearch');
  const filter = document.getElementById('libFilter');
  const container = document.getElementById('libraryContainer');
  if (!search || !filter || !container) return;
  const sv = search.value.toLowerCase();
  const fv = filter.value;
  for (const c of container.getElementsByClassName('blueprint-card')) {
    const t = c.querySelector('.blueprint-title').innerText.toLowerCase();
    const d = c.querySelector('.blueprint-desc').innerText.toLowerCase();
    const cat = c.getAttribute('data-category');
    const okS = t.includes(sv) || d.includes(sv);
    const okC = fv === 'all' || cat === fv;
    c.style.display = (okS && okC) ? 'flex' : 'none';
  }
}

/* ============================== toc =============================== */

const CT_ICON = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="4.5" cy="6" r="1.1"/><circle cx="4.5" cy="12" r="1.1"/><circle cx="4.5" cy="18" r="1.1"/><line x1="9" y1="6" x2="20" y2="6"/><line x1="9" y1="12" x2="20" y2="12"/><line x1="9" y1="18" x2="20" y2="18"/></svg>';
const TOC_LANDMARKS = [
  ['.pillars', 'Guide'], ['.obj-tracker', 'Objectives'],
  ['.checkpoint-advance', 'Checkpoint'], ['.unlock-banner', 'Branch unlocked']
];

function closeDrawer() {
  const sb = document.getElementById('sidebar'), ov = document.getElementById('overlay');
  if (sb) sb.classList.remove('open');
  if (ov) ov.classList.remove('visible');
}

// Record the current heading in the hash (route format) without adding a
// history entry and without re-triggering the router.
// Record the current heading in the hash (route format) without adding a
// history entry and without re-triggering the router.
function setHeadingHash(id) {
  const sec = document.querySelector('.content-section.active');
  if (!sec || sec.id === 'search-results') return;
  try { history.replaceState(null, '', routeUrl(sec.id, id)); } catch (e) {}
}

// Ensure unique header IDs
function getHeadings(sec) {
  const out = [], seen = {};
  const ensureId = (el, txt) => {
    if (!el.id) {
      let base = 'h-' + (sec.id || 'x') + '-' + slugify(txt), id = base, n = 2;
      while (seen[id] || document.getElementById(id)) id = base + '-' + (n++);
      seen[id] = 1; el.id = id;
    }
    return el.id;
  };
  sec.querySelectorAll('h2.section-heading').forEach(h => {
    const txt = h.textContent.trim(); if (!txt) return;
    out.push({ el: h, id: ensureId(h, txt), text: txt, level: 2 });
  });
  TOC_LANDMARKS.forEach(([sel, label]) => {
    const el = sec.querySelector(sel);
    if (el) out.push({ el, id: ensureId(el, label), text: label, level: 2 });
  });
  out.sort((a, b) => (a.el.compareDocumentPosition(b.el) & 4) ? -1 : 1);
  return out;
}

let isTOCClickScrolling = false;

function gotoHeading(id, drawer) {
  const el = document.getElementById(id);
  if (el) { 
    isTOCClickScrolling = true;
    el.scrollIntoView({ behavior: 'smooth', block: 'start' }); 
    setHeadingHash(id);
    
    // Force direct highlight on click immediately
    const rail = document.getElementById('tocRail');
    if (rail) {
      const links = [...rail.querySelectorAll('.toc-link')];
      const targetLink = links.find(a => a.dataset.tid === id);
      if (targetLink) {
        const activeIdx = links.indexOf(targetLink);
        links.forEach((a, idx) => {
          a.classList.toggle('active', a === targetLink);
          a.classList.toggle('passed', idx < activeIdx);
        });

        // Also sync mobile view directly
        const mobileRail = document.querySelector('.nav-toc');
        if (mobileRail) {
          const mLinks = [...mobileRail.querySelectorAll('a')];
          const mCur = mLinks.find(a => a.dataset.tid === id);
          if (mCur) {
            const mActiveIdx = mLinks.indexOf(mCur);
            mLinks.forEach((a, idx) => {
              a.classList.toggle('active', a === mCur);
              a.classList.toggle('passed', idx < mActiveIdx);
            });
          }
        }
      }
    }

    setTimeout(() => {
      isTOCClickScrolling = false;
    }, 800);
  }
  if (drawer) closeDrawer();
}

function buildRail(headings) {
  const rail = document.getElementById('tocRail'); if (!rail) return;
  if (headings.length < 2) { rail.classList.add('empty'); rail.innerHTML = ''; return; }
  rail.classList.remove('empty');
  let html = '<div class="toc-rail-title">On this page</div>';
  headings.forEach(h => {
    html += '<a class="toc-link lvl' + h.level + '" href="#" data-tid="' + h.id + '">'
      + h.text.replace(/&/g, '&amp;').replace(/</g, '&lt;') + '</a>';
  });
  rail.innerHTML = html;
  rail.querySelectorAll('.toc-link').forEach(a => {
    a.addEventListener('click', e => { e.preventDefault(); gotoHeading(a.dataset.tid, false); });
  });
}

function decorateNav(headings) {
  document.querySelectorAll('.nav-ct, .nav-toc').forEach(n => n.remove());
  const active = document.querySelector('.nav-item.active');
  if (!active || headings.length < 1) return;
  const ct = document.createElement('span');
  ct.className = 'nav-ct'; ct.setAttribute('role', 'button');
  ct.setAttribute('aria-label', 'Contents of this tab'); ct.innerHTML = CT_ICON;
  active.appendChild(ct);
  const toc = document.createElement('div');
  toc.className = 'nav-toc';
  headings.forEach(h => {
    const a = document.createElement('a');
    a.className = 'lvl' + h.level; a.href = '#'; a.textContent = h.text;
    a.dataset.tid = h.id;
    a.addEventListener('click', e => { e.preventDefault(); gotoHeading(h.id, true); });
    toc.appendChild(a);
  });
  active.insertAdjacentElement('afterend', toc);
  ct.addEventListener('click', e => { e.stopPropagation(); e.preventDefault(); toc.classList.toggle('open'); });
}

export function refreshTOC() {
  const sec = document.querySelector('.content-section.active');
  const rail = document.getElementById('tocRail');
  if (!sec || sec.id === 'search-results') {
    if (rail) { rail.classList.add('empty'); rail.innerHTML = ''; }
    document.querySelectorAll('.nav-ct, .nav-toc').forEach(n => n.remove());
    return;
  }
  const headings = getHeadings(sec);
  buildRail(headings);
  decorateNav(headings);
}

export function initScrollSpy() {
  let raf = null, lastHash = '';
  window.addEventListener('scroll', () => {
    if (raf || isTOCClickScrolling) return;
    raf = requestAnimationFrame(() => {
      raf = null;
      const rail = document.getElementById('tocRail');
      if (!rail || rail.classList.contains('empty')) return;
      const links = [...rail.querySelectorAll('.toc-link')];
      if (!links.length) return;

      let cur = null;
      let closestDist = Infinity;

      // Only apply sweeping threshold when near the very bottom of the document
      let sweepLine = 140;
      const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
      if (maxScroll > 0 && window.scrollY >= maxScroll - 150) {
        const scrollPct = (window.scrollY - (maxScroll - 150)) / 150;
        sweepLine = 140 + Math.max(0, Math.min(1, scrollPct)) * (window.innerHeight - 220);
      }

      links.forEach((a) => {
        const el = document.getElementById(a.dataset.tid);
        if (!el) return;
        const rect = el.getBoundingClientRect();
        const dist = Math.abs(rect.top - sweepLine);
        if (dist < closestDist) {
          closestDist = dist;
          cur = a;
        }
      });

      if (!cur && links.length) cur = links[0];

      // Update active and passed states on the desktop TOC rail
      const activeIdx = links.indexOf(cur);
      links.forEach((a, idx) => {
        a.classList.toggle('active', a === cur);
        a.classList.toggle('passed', idx < activeIdx);
      });

      // Update the exact same active and passed states on the mobile TOC menu
      const mobileRail = document.querySelector('.nav-toc');
      if (mobileRail) {
        const mLinks = [...mobileRail.querySelectorAll('a')];
        const mCur = mLinks.find(a => a.dataset.tid === (cur ? cur.dataset.tid : ''));
        const mActiveIdx = mLinks.indexOf(mCur);
        mLinks.forEach((a, idx) => {
          a.classList.toggle('active', a === mCur);
          a.classList.toggle('passed', idx < mActiveIdx);
        });
      }

      if (cur && cur.dataset.tid !== lastHash) { 
        lastHash = cur.dataset.tid; 
        setHeadingHash(cur.dataset.tid); 
      }
    });
  }, { passive: true });
}

/* ============================== init ============================== */

export function initContent() {
  initProgress();
  initCollapsibles();
  initResourceLists();

  // Find active level tab and run benchmark pinning safely during tab mount
  const activeSection = document.querySelector('#tab-mount > .content-section.active') || document.querySelector('#tab-mount > .content-section');
  if (activeSection) {
    setupBenchmarkPinning(activeSection);
  }

  // Inject style block to clean backgrounds, borders, and align controls perfectly [2.3]
  const altStyle = document.createElement('style');
  altStyle.textContent = `
    /* Clear custom/legacy backgrounds, shadows and border duplicates */
    .alternatives-content .res, 
    .alternatives-content .res[open], 
    .alternatives-content .res > summary,
    .alternatives-content .res-more,
    .alternatives-content .res-cell {
        background: transparent !important;
        background-color: transparent !important;
        box-shadow: none !important;
    }
    .alternatives-content .res-cell {
        border: none !important;
        padding: 0 !important;
    }
    .res-controls .res-done-toggle {
        margin-left: 0 !important;
    }
    /* Style overrides for custom checkbox in resources controls */
    .res-controls .res-done-toggle {
        width: 20px !important;
        height: 20px !important;
        border-radius: 50% !important;
        border: 2px solid var(--border-color) !important;
        display: inline-flex !important;
        align-items: center !important;
        justify-content: center !important;
        background: transparent !important;
    }
  `;
  document.head.appendChild(altStyle);

  window.toggleCollapse = toggleCollapse;
  window.filterLibrary = filterLibrary;
}

/**
 * Setup and manage era benchmark selections and pinning states cleanly.
 * Displays selection onboarding options for first-time visits, automatically
 * moving alternatives to the correct drawer to prevent state conflicts.
 * If all items are unpinned, the selection flow correctly resets.
 */
export function setupBenchmarkPinning(tabElement) {
    const levelId = tabElement.id;
    if (!levelId || (!levelId.startsWith('level-') && levelId !== 'pre-staff')) return;

    const uvBenchmarksContainer = tabElement.querySelector('.uv-benchmarks');
    const altDrawer = tabElement.querySelector('.alt-bench-drawer');
    const altList = tabElement.querySelector('.alt-bench-list');
    if (!uvBenchmarksContainer || !altList) return;

    // Get only selectable era items (excluding Method Audition cards by checking for pin buttons)
    const allItems = Array.from(tabElement.querySelectorAll('.uv-bench-item[data-bench-id]'))
                          .filter(item => item.querySelector('.bench-pin-btn'));
    if (allItems.length === 0) return;

    const storageKey = `cp-pinned-benchmarks-${levelId}`;
    const hasSelectedKey = `cp-has-selected-${levelId}`;
    
    let pinnedIds = [];
    const savedPinned = localStorage.getItem(storageKey);
    const hasSelectedVal = localStorage.getItem(hasSelectedKey);
    
    // Defensive reset logic: if they have stale selection arrays but never completed 
    // onboarding selection flow, force them into the onboarding flow cleanly [1.4]
    if (savedPinned && hasSelectedVal === 'true') {
        pinnedIds = JSON.parse(savedPinned);
    } else {
        pinnedIds = [];
        localStorage.setItem(storageKey, JSON.stringify([]));
        localStorage.setItem(hasSelectedKey, 'false');
    }

    function render() {
        const banner = tabElement.querySelector('.uv-bench-onboarding-banner');
        
        // Derive selection state strictly from pinned benchmark IDs [1.4]
        const currentHasSelected = pinnedIds.length > 0;
        localStorage.setItem(hasSelectedKey, currentHasSelected ? 'true' : 'false');

        if (!currentHasSelected && allItems.length > 1) {
            if (!banner) {
                const newBanner = document.createElement('div');
                newBanner.className = 'uv-bench-onboarding-banner';
                newBanner.innerHTML = `
                    <div style="background: rgba(201, 168, 76, 0.08); border: 1px solid var(--gold); border-radius: 8px; padding: 1.1rem; margin-bottom: 1.25rem;">
                        <h5 style="margin: 0 0 0.5rem; color: var(--gold); font-size: 0.95rem; font-weight: 700; display: flex; align-items: center; gap: 0.5rem; font-family: 'Space Grotesk', sans-serif;">
                            <svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 16px; height: 16px; color: var(--gold);"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
                            Choose Your Primary Era Benchmark
                        </h5>
                        <p style="margin: 0; font-size: 0.88rem; color: var(--text-muted); line-height: 1.5;">
                            Please select <strong>one</strong> era piece to focus on for this level. Once chosen, the alternative pieces will automatically move to the "Alternative Era Benchmark Pieces" drawer below. You can change this selection later or pin additional pieces using the pin icons.
                        </p>
                    </div>
                `;
                uvBenchmarksContainer.parentNode.insertBefore(newBanner, uvBenchmarksContainer);
            }

            allItems.forEach(item => {
                item.style.cursor = 'pointer';
                item.classList.add('onboarding-selectable');
                
                let selectBtn = item.querySelector('.bench-select-helper-btn');
                if (!selectBtn) {
                    selectBtn = document.createElement('button');
                    selectBtn.className = 'bench-select-helper-btn widget-btn';
                    selectBtn.style.marginTop = '0.75rem';
                    selectBtn.style.width = '100%';
                    selectBtn.style.textAlign = 'center';
                    selectBtn.style.display = 'block';
                    selectBtn.innerHTML = `
                        <svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 12px; height: 12px; margin-right: 4px; vertical-align: -1px;"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3" fill="currentColor"/></svg>
                        Select This Benchmark
                    `;
                    item.appendChild(selectBtn);
                }
            });
        } else {
            if (banner) {
                banner.remove();
            }
            allItems.forEach(item => {
                item.style.cursor = '';
                item.classList.remove('onboarding-selectable');
                const selectBtn = item.querySelector('.bench-select-helper-btn');
                if (selectBtn) selectBtn.remove();
            });
        }

        let hasUnpinned = false;
        allItems.forEach(item => {
            const id = item.getAttribute('data-bench-id');
            const isPinned = pinnedIds.includes(id);
            
            // Set data-pinned attribute based strictly on state
            item.setAttribute('data-pinned', isPinned ? 'true' : 'false');
            const shouldShowInMain = !currentHasSelected || isPinned;

            if (shouldShowInMain) {
                if (item.parentNode !== uvBenchmarksContainer) {
                    uvBenchmarksContainer.appendChild(item);
                }
            } else {
                if (item.parentNode !== altList) {
                    altList.appendChild(item);
                }
                hasUnpinned = true;
            }

            // Upgrade pin button structure to hold pin-icon-on and pin-icon-off for slashed hover state
            const pinBtn = item.querySelector('.bench-pin-btn');
            if (pinBtn && !pinBtn.querySelector('.pin-icon-off')) {
                pinBtn.innerHTML = `
                    <svg class="ic pin-icon-on" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="12" y1="17" x2="12" y2="22"></line>
                        <path d="M5 17h14v-1.76a2 2 0 0 0-.44-1.24l-2.12-2.65A1 1 0 0 1 16 10.76V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v5.76a1 1 0 0 1-.44.59l-2.12 2.65a2 2 0 0 0-.44 1.24Z"></path>
                    </svg>
                    <svg class="ic pin-icon-off" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">
                        <line x1="12" y1="17" x2="12" y2="22"></line>
                        <path d="M5 17h14v-1.76a2 2 0 0 0-.44-1.24l-2.12-2.65A1 1 0 0 1 16 10.76V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v5.76a1 1 0 0 1-.44.59l-2.12 2.65a2 2 0 0 0-.44 1.24Z"></path>
                        <line x1="2" y1="2" x2="22" y2="22" stroke="currentColor" stroke-width="2"></line>
                    </svg>
                `;
            }
            if (pinBtn) {
                pinBtn.title = isPinned ? 'Unpin from main list' : 'Pin to main list';
            }
        });

        if (altDrawer) {
            altDrawer.style.display = hasUnpinned ? 'block' : 'none';
        }
    }

    // Set up Controls (Pin Button Wrapper and Checkbox) once for each item
    allItems.forEach(item => {
        const topRow = item.querySelector('.uv-bench-top');
        if (topRow && !item._controlsInitialized) {
            item._controlsInitialized = true;
            
            let controls = item.querySelector('.bench-controls');
            let pinBtn = item.querySelector('.bench-pin-btn');
            
            if (!controls) {
                controls = document.createElement('div');
                controls.className = 'bench-controls';
                
                // Keep layout clean and align pin controls completely to the right edge of the card [1.4]
                controls.style.marginLeft = 'auto';
                controls.style.display = 'flex';
                controls.style.alignItems = 'center';
                controls.style.gap = '12px';

                topRow.style.display = 'flex';
                topRow.style.alignItems = 'center';
                topRow.style.width = '100%';
                
                if (pinBtn) {
                    controls.appendChild(pinBtn);
                }
                
                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.className = 'bench-done-checkbox';
                checkbox.id = `check-bench-${item.getAttribute('data-bench-id')}`;
                controls.appendChild(checkbox);
                
                topRow.appendChild(controls);
            }
        }

        // Restore checkbox checked state and class
        const checkbox = item.querySelector('.bench-done-checkbox');
        if (checkbox) {
            const isChecked = localStorage.getItem(checkbox.id) === 'true';
            checkbox.checked = isChecked;
            item.classList.toggle('completed', isChecked);
        }

        // Setup Event Listeners
        const pinBtn = item.querySelector('.bench-pin-btn');
        if (pinBtn && !pinBtn._pinHandlerAdded) {
            pinBtn._pinHandlerAdded = true;
            pinBtn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                
                const id = item.getAttribute('data-bench-id');
                const idx = pinnedIds.indexOf(id);

                if (idx > -1) {
                    pinnedIds.splice(idx, 1);
                } else {
                    pinnedIds.push(id);
                }
                
                localStorage.setItem(storageKey, JSON.stringify(pinnedIds));
                if (pinnedIds.length > 0 && altDrawer) {
                    altDrawer.open = false; // Collapse alternatives drawer immediately [2.1]
                }
                render();
            });
        }

        if (!item._cardHandlerAdded) {
            item._cardHandlerAdded = true;
            item.addEventListener('click', (e) => {
                if (item.classList.contains('onboarding-selectable')) {
                    // Avoid catching direct links clicked on the card text
                    if (e.target.tagName === 'A' || e.target.closest('a')) {
                        return;
                    }
                    e.preventDefault();
                    const id = item.getAttribute('data-bench-id');
                    pinnedIds = [id];
                    localStorage.setItem(storageKey, JSON.stringify(pinnedIds));
                    if (altDrawer) {
                        altDrawer.open = false; // Collapse alternatives drawer immediately [2.1]
                    }
                    render();
                }
            });
        }
    });

    if (altList) {
        altList.style.display = 'flex';
        altList.style.flexDirection = 'column';
        altList.style.gap = '1.25rem'; // Increased gap between alternative benchmarks [2.2]
    }

    render();
}
